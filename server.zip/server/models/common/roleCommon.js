module.exports = {
  create: { type: Boolean, default: false },
  read: { type: Boolean, default: false },
  write: { type: Boolean, default: false },
  delete: { type: Boolean, default: false },
};
