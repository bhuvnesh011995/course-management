module.exports = {
  designation: require("./designation.model"),
  emailtemplates: require("./emailTemplate.model"),
  duration: require("./duration.modal"),
  department: require("./departmentModel"),
  position: require("./positionModel"),
  leave: require("./leaveModel"),
};
