module.exports = {
    systemConfig:require("./systemConfigModel"),
    otherConfig:require("./otherConfigModel")
}